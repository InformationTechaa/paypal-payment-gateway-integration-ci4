<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use PayPalCheckoutSdk\Core\PayPalHttpClient;
use PayPalCheckoutSdk\Core\SandboxEnvironment;
use PayPalHttp\HttpException;
use PayPalCheckoutSdk\Orders\OrdersCreateRequest;
use PayPalCheckoutSdk\Orders\OrdersGetRequest;
use Config\PayPal;

class PaymentController extends BaseController
{
    public function index()
    {
        return view('payment');
    }

    public function processPayment()
    {
        try {
            // Set up PayPal SDK environment
            $clientId = PayPal::$clientId;
            $clientSecret = PayPal::$clientSecret;
            $baseUrl = PayPal::$baseUrl;
            
            $environment = new SandboxEnvironment($clientId, $clientSecret);
            $client = new PayPalHttpClient($environment);

            // Prepare the payment request
            $requestBody = [
                'intent' => 'CAPTURE',
                'purchase_units' => [
                    [
                        'amount' => [
                            'currency_code' => 'USD',
                            'value' => '100.00' // Set the payment amount here
                        ]
                    ]
                ],
                'application_context' => [
                    'return_url' => base_url('payment/handlePaymentCallback'),
                    'cancel_url' => base_url('payment') // URL to redirect if the user cancels the payment
                ]
            ];

            // Create the payment request
            $request = new OrdersCreateRequest();
            $request->prefer('return=representation');
            $request->body = $requestBody;

            // Send the payment request to PayPal
            $response = $client->execute($request);

            // Extract the approval link from the response
            $approvalUrl = $this->extractApprovalUrl($response);

            // Redirect the user to PayPal for payment approval
            return redirect()->to($approvalUrl);
        } catch (HttpException $ex) {
            // Handle any errors from PayPal
            $errorMessage = $ex->getMessage();
            // Redirect the user to an error page or display an error message
            // Example: return redirect()->to(base_url('error'))->with('error', $errorMessage);
        }
    }

    public function handlePaymentCallback()
    {
        try {
            // Set up PayPal SDK environment
            $clientId = PayPal::$clientId;
            $clientSecret = PayPal::$clientSecret;
            $baseUrl = PayPal::$baseUrl;

            $environment = new SandboxEnvironment($clientId, $clientSecret);
            $client = new PayPalHttpClient($environment);

            // Extract the order ID from the URL query parameters
            $orderId = $_GET['token']; // or $_GET['orderID'], depending on PayPal configuration

            // Prepare the request to fetch order details
            $request = new OrdersGetRequest($orderId);

            // Fetch order details from PayPal
            $response = $client->execute($request);
           /*  echo "<pre>";
            print_r($response);exit('sss'); */

            // Handle the payment status
            $statusCode = $response->statusCode;
            if ($statusCode == 200) {
                // Payment is successful
                $order = $response->result;

                // Extract relevant order details (e.g., transaction ID, total amount)
                $transactionId = $order->id;
                $totalAmount = $order->purchase_units[0]->amount->value;

                // Process the successful payment (e.g., update database, send confirmation email)
                // Example: $this->orderModel->updatePaymentStatus($orderId, 'completed');
                // Example: $this->emailService->sendConfirmationEmail($orderId);

                // Redirect the user to a thank you page
                return redirect()->to(base_url('thank-you'))->with('success', 'Payment successful. Thank you!');
            } else {
                // Payment failed
                // Redirect the user to an error page or display an error message
                return redirect()->to(base_url('error'))->with('error', 'Payment failed. Please try again later.');
            }
        } catch (HttpException $ex) {
            // Handle any errors from PayPal
            $errorMessage = $ex->getMessage();
            // Redirect the user to an error page or display an error message
            return redirect()->to(base_url('error'))->with('error', $errorMessage);
        }
    }

    private function extractApprovalUrl($response)
    {
        $links = $response->result->links;
        foreach ($links as $link) {
            if ($link->rel === 'approve') {
                return $link->href;
            }
        }
        throw new \Exception('Approval URL not found in PayPal response.');
    }

    public function thank_you()
    {
        echo "thank_you";exit;
    }

    public function error()
    {
        echo "error";exit;
    }
}
