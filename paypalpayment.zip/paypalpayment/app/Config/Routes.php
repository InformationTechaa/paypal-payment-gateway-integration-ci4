<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->get('payment', 'PaymentController::index');
$routes->post('payment/processPayment', 'PaymentController::processPayment');
$routes->get('payment/handlePaymentCallback', 'PaymentController::handlePaymentCallback');



$routes->get('thank-you', 'PaymentController::thank_you');
$routes->get('error', 'PaymentController::error');
