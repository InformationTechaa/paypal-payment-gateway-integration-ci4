<?php

namespace Config;

class PayPal
{
    public static $clientId = 'AQNglDTxVbv2Y2X9ev2aak2En8EGm-cGpDze2_xzgMK1FEkMcgp6zN9fes-vTsK81dSI5WjlnVyjY49b';
    public static $clientSecret = 'EH6JDXsMiulEdpd3AAxl_lLc2u6hMD8mOBtPjiMjxS7k9rT4DJrIvFS7hNMCzCnBU5QXfcCRAv14my21';
    public static $baseUrl = 'https://api-m.sandbox.paypal.com'; // For Sandbox
    // public static $baseUrl = 'https://api-m.paypal.com'; // For Live
}
