<!-- File: app/Views/payment.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
</head>
<body>
    <h1>Make a Payment</h1>
    <form action="<?= base_url('payment/processPayment') ?>" method="post">
        <!-- Add your payment form fields here -->
        <label for="amount">Amount:</label>
        <input type="text" id="amount" name="amount" required>
        <button type="submit">Pay with PayPal</button>
    </form>
</body>
</html>
